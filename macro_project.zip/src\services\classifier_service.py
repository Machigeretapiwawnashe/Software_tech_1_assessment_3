"""Classification service for training and saving a macroinvertebrate image classifier."""

from pathlib import Path
import numpy as np
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report
from typing import Optional
from src.config import MODEL_OUTPUT_DIR


class ClassifierService:
    """Train and save an image classifier using Random Forest or SVM."""

    SUPPORTED_MODELS = ("random_forest", "svm")

    def __init__(
        self,
        model_type: str = "random_forest",
        output_dir: Path = MODEL_OUTPUT_DIR,
    ) -> None:
        """Initialize with a model type ('random_forest' or 'svm') and output directory."""
        if model_type not in self.SUPPORTED_MODELS:
            raise ValueError(
                f"model_type must be one of {self.SUPPORTED_MODELS}, got '{model_type}'"
            )

        self.model_type = model_type
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.model = self._build_model()

    def _build_model(self):
        """Create a new model instance based on the selected type."""
        if self.model_type == "random_forest":
            return RandomForestClassifier(
                n_estimators=100,
                random_state=42,
                n_jobs=-1,  # Use all available CPU cores
                class_weight='balanced'  # Handle class imbalance
            )
        return SVC(kernel="rbf", probability=True, random_state=42)

    def _flatten(self, X: np.ndarray) -> np.ndarray:
        """Convert images from 4-D to 2-D arrays for the classifier."""
        return X.reshape(len(X), -1)

    def train(self, X_train: np.ndarray, y_train: np.ndarray) -> None:
        """Train the classifier on the given images and labels."""
        X_flat = self._flatten(X_train)
        self.model.fit(X_flat, y_train)
        self._save_training_report(X_train, y_train)

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict class indices for the given images."""
        return self.model.predict(self._flatten(X))

    def _save_training_report(self, X_train: np.ndarray, y_train: np.ndarray) -> None:
        """Save a classification report to disk."""
        predictions = self.predict(X_train)
        report = classification_report(y_train, predictions, zero_division=0)
        
        report_path = self.output_dir / "training_report.txt"
        with open(report_path, "w") as f:
            f.write("Training Classification Report\n")
            f.write("=" * 40 + "\n")
            f.write(report)
            f.write(f"\nModel Type: {self.model_type}\n")
            f.write(f"Training Samples: {len(X_train)}\n")

    def evaluate(self, X_test: np.ndarray, y_test: np.ndarray) -> float:
        """Calculate accuracy on the test set."""
        predictions = self.predict(X_test)
        return float(accuracy_score(y_test, predictions))

    def save(self, filename: str = "classifier.joblib") -> Path:
        """Save the trained model to disk."""
        save_path = self.output_dir / filename
        joblib.dump(self.model, save_path)
        return save_path

    def save_class_names(self, class_names: list[str], filename: str = "class_names.txt") -> Path:
        """Save class names to a text file."""
        save_path = self.output_dir / filename
        with open(save_path, "w", encoding="utf-8") as f:
            for name in class_names:
                f.write(f"{name}\n")
        return save_path

    def load_class_names(self, filename: str = "class_names.txt") -> list[str]:
        """Load class names from a text file."""
        load_path = self.output_dir / filename
        if not load_path.exists():
            raise FileNotFoundError(f"Class names file not found: {load_path}")
        with open(load_path, "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip()]

    def load(self, filename: str = "classifier.joblib") -> None:
        """Load a saved model from disk."""
        load_path = self.output_dir / filename
        self.model = joblib.load(load_path)
