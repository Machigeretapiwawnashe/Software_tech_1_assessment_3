# Implementation Summary

## Project Title and Group Members
- Project title: Macroinvertebrate Image Analysis System
- Group members: Taps Machigere, Will Ness

## Brief Project Goal
Build a Python application that performs exploratory data analysis and classification on the Kaggle Stream Macroinvertebrates image dataset. The system is designed to demonstrate object-oriented design, structured data processing, visualization, and predictive analytics.

## Dataset Setup
The project requires the Kaggle Stream Macroinvertebrates image dataset. To set up the data:

1. **Download the dataset** from Kaggle:
   - Visit: https://www.kaggle.com/datasets/stream-macroinvertebrates (or the specific dataset link if different)
   - Download the dataset to your local machine

2. **Place the data in the correct location**:
   - Extract the downloaded dataset
   - Copy all class folders (e.g., `Asellus sp/`, `Baetidae sp/`, `Elmis sp/`, etc.) into the `data/raw/` directory
   - The final structure should look like:
     ```
     macro_project/
     └── data/
         └── raw/
             ├── Asellus sp/
             ├── Baetidae sp/
             └── ... (all other class folders)
     ```

3. **Verify setup**: Once data is placed, you can run the full pipeline to process and analyze the dataset.

## System Design
The project uses a modular architecture with separate service classes for each major workflow stage. The top-level `run.py` script now launches a unified interactive menu, while `src/main.py` still orchestrates the underlying pipeline:
- Stage 1: Exploratory Data Analysis (EDA)
- Stage 2: Image preprocessing, training, and model evaluation
- Stage 3: Deployment interface and live classification for selected classes or images

Configuration is centralized in `src/config.py`, and outputs are saved under `outputs/eda/` and `outputs/models/`.

## Class and Module Overview
- `src/services/dataset_indexer.py`
  - Scans `data/raw/` for image files
  - Extracts labels from folder names and collects image metadata
  - Builds a `pandas` DataFrame with image paths, labels, and dimensions

- `src/services/eda_service.py`
  - Generates EDA visualizations and analysis summaries
  - Saves charts for class distribution, image size distribution, sample grids, imbalance analysis, and pixel intensity analysis

- `src/services/preprocessor.py`
  - Loads images from disk using OpenCV
  - Resizes images to a consistent size and normalizes pixel values
  - Encodes labels and splits data into training and test sets
  - Supports loading a single image for live prediction

- `src/services/classifier_service.py`
  - Trains a Random Forest classifier on the preprocessed image data
  - Evaluates test performance and saves the trained model
  - Saves and loads class name metadata for live deployment

- `src/services/model_evaluator.py`
  - Evaluates model results with a confusion matrix and per-class accuracy plot
  - Saves evaluation charts to `outputs/models/`

- `stage3.py`
  - Provides a console-based Stage 3 deployment interface
  - Runs the pipeline, classifies new images, and shows saved output files
  - Supports selecting classes and then choosing either one image from the selected classes or all images in the selected set

## Tools and Libraries Used
- `pandas` — dataset indexing and tabular management
- `numpy` — numerical operations and array handling
- `opencv-python` — image loading and preprocessing
- `matplotlib`, `seaborn` — visualization and charts
- `Pillow` — image utilities for testing and sample generation
- `scikit-learn` — classification, evaluation, and label encoding
- `joblib` — saving and loading the trained model

## Key Features Implemented
- Dataset indexing with class labels and image metadata
- EDA chart generation for dataset exploration
- Image preprocessing pipeline with resizing and normalization
- Random Forest classification model training
- Model evaluation and chart output generation
- Unit and end-to-end testing support

## Current Results
From the current dataset in `data/raw/`:
- Total classes: `17`
- Total images: `2665`
- Train/test split: `2132` training, `533` testing
- Test accuracy: `73.92%`
- EDA outputs: `outputs/eda/`
- Model saved: `outputs/models/classifier.joblib`


## Reused or Adapted Code
- No external code was reused beyond standard library and package functionality unless otherwise documented.

## Work Division
- Taps Machigere: Stage 1 EDA, dataset indexing, metadata extraction, visualization, and Stage 3 deployment/interface
- Will Ness: Stage 2 preprocessing, Random Forest classification, model evaluation, saving outputs, and Stage 3 deployment/interface

## How to Run

The primary entry point to the system is the interactive menu launched by `run.py`:
```bash
python run.py
```

This command launches the **Stage 3 interactive menu** which provides the following options:
- **Option 1**: Run the full pipeline (Stage 1 EDA + Stage 2 model training and evaluation)
- **Option 2**: Classify a single new image using the saved model
- **Option 3**: Select specific classes and classify either one image or all images from those classes
- **Option 4**: View saved output files and directories
- **Option 5**: Exit

### Alternative Entry Points

To run the pipeline directly without the interactive menu, use:
```bash
python main.py
```

To access the Stage 3 deployment interface directly (bypassing run.py), use:
```bash
python stage3.py
```

### Output Locations
The pipeline saves results to:
- EDA outputs: `outputs/eda/` (charts and analysis summaries)
- Model and evaluation results: `outputs/models/` (trained classifier and evaluation charts)
