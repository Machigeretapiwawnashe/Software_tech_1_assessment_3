from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import cv2
from typing import Dict, Union

class EDAService:
    """Generate and save exploratory data analysis visualizations."""

    def __init__(self, dataframe: pd.DataFrame, output_dir: Path) -> None:
        self.dataframe = dataframe
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def save_class_distribution(self) -> None:
        """Save a bar chart showing the count of images per class."""
        plt.figure(figsize=(12, 6))
        order = self.dataframe["label"].value_counts().index
        sns.countplot(data=self.dataframe, x="label", order=order)
        plt.xticks(rotation=90)
        plt.title("Macroinvertebrate Images per Class")
        plt.tight_layout()
        plt.savefig(self.output_dir / "class_distribution.png")
        plt.close()

    def save_image_size_distribution(self) -> None:
        """Save histograms of image width and height."""
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        sns.histplot(self.dataframe["width"], bins=20, ax=axes[0])
        sns.histplot(self.dataframe["height"], bins=20, ax=axes[1])
        axes[0].set_title("Image Width Distribution")
        axes[1].set_title("Image Height Distribution")
        plt.tight_layout()
        plt.savefig(self.output_dir / "image_size_distribution.png")
        plt.close()

    def save_sample_grid(self, sample_count: int = 9) -> None:
        """Save a grid of random images for visual inspection."""
        sample_df = self.dataframe.sample(min(sample_count, len(self.dataframe)), random_state=42)
        fig, axes = plt.subplots(3, 3, figsize=(10, 10))

        for ax, (_, row) in zip(axes.flat, sample_df.iterrows()):
            image = cv2.imread(row["file_path"])
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            ax.imshow(image)
            ax.set_title(row["label"])
            ax.axis("off")

        for ax in axes.flat[len(sample_df):]:
            ax.axis("off")

        plt.tight_layout()
        plt.savefig(self.output_dir / "sample_grid.png")
        plt.close()

    def save_class_imbalance_analysis(self) -> None:
        """Save a color-coded bar chart showing class imbalance severity."""
        class_counts = self.dataframe["label"].value_counts()
        mean_count = class_counts.mean()
        
        colors = []
        for count in class_counts:
            if count < mean_count * 0.5:
                colors.append('red')
            elif count < mean_count * 0.8:
                colors.append('orange')
            else:
                colors.append('green')
        
        plt.figure(figsize=(12, 6))
        bars = plt.bar(range(len(class_counts)), class_counts.values, color=colors)
        plt.xticks(range(len(class_counts)), class_counts.index, rotation=90)
        plt.axhline(y=mean_count, color='blue', linestyle='--', label=f'Mean: {mean_count:.1f}')
        plt.title("Class Imbalance Analysis (Green: Balanced, Orange: Moderate, Red: Severe)")
        plt.ylabel("Number of Images")
        plt.legend()
        
        for bar, count in zip(bars, class_counts):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5, 
                    f'{count}', ha='center', va='bottom')
        
        plt.tight_layout()
        plt.savefig(self.output_dir / "class_imbalance_analysis.png")
        plt.close()
        
    def save_pixel_intensity_analysis(self) -> None:
        """Save a bar chart of mean pixel intensity per class."""
        intensity_means = {}
        
        for label in self.dataframe["label"].unique():
            class_images = self.dataframe[self.dataframe["label"] == label]
            intensities = []
            
            for _, row in class_images.iterrows():
                image = cv2.imread(row["file_path"], cv2.IMREAD_GRAYSCALE)
                if image is not None:
                    intensities.append(image.mean())
            
            if intensities:
                intensity_means[label] = sum(intensities) / len(intensities)
            else:
                intensity_means[label] = 0
        
        sorted_intensities = sorted(intensity_means.items(), key=lambda x: x[1])
        labels, values = zip(*sorted_intensities)
        
        plt.figure(figsize=(10, max(6, len(labels) * 0.3)))
        bars = plt.barh(labels, values, color='skyblue')
        plt.xlabel("Mean Grayscale Intensity (0-255)")
        plt.title("Pixel Intensity Analysis per Class")
        
        for bar, value in zip(bars, values):
            plt.text(bar.get_width() + 1, bar.get_y() + bar.get_height()/2, 
                    f'{value:.1f}', va='center')
        
        plt.tight_layout()
        plt.savefig(self.output_dir / "pixel_intensity_analysis.png")
        plt.close()
        
    def build_stage2_commentary(self) -> None:
        """Write a file linking EDA findings to Stage 2 preprocessing decisions."""
        summary = self.build_summary()
        class_counts = self.dataframe["label"].value_counts()
        imbalance_ratio = class_counts.max() / class_counts.min() if len(class_counts) > 1 else 1
        size_variance = self.dataframe["width"].std() + self.dataframe["height"].std()
        
        commentary = f"""EDA to Stage 2 Preprocessing Commentary

Dataset Overview:
- Total images: {summary['total_images']}
- Total classes: {summary['total_classes']}
- Mean dimensions: {summary['mean_width']:.1f} x {summary['mean_height']:.1f} pixels

Key EDA Findings:
1. Class Imbalance: The dataset shows an imbalance ratio of {imbalance_ratio:.2f} 
   (max class: {class_counts.max()}, min class: {class_counts.min()}).
   This indicates some classes are underrepresented.

2. Size Variance: Combined width/height standard deviation is {size_variance:.2f} pixels,
   suggesting images vary significantly in size, requiring standardization.

Stage 2 Decisions Based on EDA:
- Resizing: All images resized to 128x128 to handle size variance and ensure consistent input.
- Normalization: Pixel values divided by 255.0 for 0-1 scaling, addressing intensity variations.
- Class Balancing: Random Forest classifier uses class_weight='balanced' to compensate for imbalance.
- Train/Test Split: Stratified split maintains class proportions despite imbalance.

These preprocessing steps directly address the variance and imbalance identified in the EDA phase.
"""
        
        with open(self.output_dir / "eda_stage2_commentary.txt", "w") as f:
            f.write(commentary)

    def build_summary(self) -> Dict[str, Union[int, float]]:
        """Return a summary table of dataset statistics."""
        return {
            "total_images": int(len(self.dataframe)),
            "total_classes": int(self.dataframe["label"].nunique()),
            "mean_width": float(self.dataframe["width"].mean()),
            "mean_height": float(self.dataframe["height"].mean())
        }
