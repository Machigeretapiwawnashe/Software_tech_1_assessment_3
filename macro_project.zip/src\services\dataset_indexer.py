from pathlib import Path
import cv2
import pandas as pd
from src.config import RAW_DATA_DIR, SUPPORTED_EXTENSIONS
from src.models.records import ImageRecord
import dataclasses

class DatasetIndexer:
    """Scan image folders and build a DataFrame with image metadata."""

    def __init__(self, data_dir: Path = RAW_DATA_DIR) -> None:
        self.data_dir = data_dir

    def build_dataframe(self) -> pd.DataFrame:
        """Return one row per image with file path, label, and dimensions."""
        records = []

        for file_path in self.data_dir.rglob("*"):
            if file_path.suffix.lower() not in SUPPORTED_EXTENSIONS:
                continue

            image = cv2.imread(str(file_path))
            if image is None:
                continue

            height, width = image.shape[:2]
            channels = image.shape[2] if len(image.shape) == 3 else 1
            label = file_path.parent.name

            record = ImageRecord(
                file_path=file_path,
                label=label,
                width=width,
                height=height,
                channels=channels,
            )
            records.append(record)

        return pd.DataFrame([dataclasses.asdict(r) for r in records])