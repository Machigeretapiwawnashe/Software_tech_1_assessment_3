from dataclasses import dataclass
from pathlib import Path

@dataclass
class ImageRecord:
    """Store image file path, class label, and dimensions."""
    file_path: Path
    label: str
    width: int
    height: int
    channels: int