# Manual Testing Documentation

This document outlines manual testing scenarios for error handling in the macro project code.

## Error Handling Table

| Scenario | Description | Expected Behavior | Actual Handling |
|----------|-------------|-------------------|-----------------|
| Missing dataset folder | The `RAW_DATA_DIR` does not exist or is empty | DatasetIndexer should handle gracefully, returning an empty DataFrame | `rglob("*")` returns no files, resulting in empty DataFrame. No exception raised. |
| Invalid image paths | Image files are corrupted or not readable by OpenCV | Skip invalid images and continue processing | `cv2.imread()` returns None for invalid files, which are skipped in the loop. |
| Missing output directory | The `EDA_OUTPUT_DIR` does not exist when saving plots | EDAService should create the directory or raise an informative error | Output directory is created automatically in __init__ using mkdir(parents=True, exist_ok=True). |
| Invalid DataFrame columns | DataFrame passed to EDAService lacks required columns (e.g., "label", "width", "height") | Raise KeyError or provide default behavior | Accessing non-existent columns (e.g., `self.dataframe["label"]`) raises KeyError. |
| Unsupported image formats | Files with extensions not in SUPPORTED_EXTENSIONS | Skip unsupported files | Only processes files with suffixes in SUPPORTED_EXTENSIONS. |
| Empty DataFrame | No valid images found | EDAService methods should handle empty DataFrame | `len(self.dataframe)` is 0, `sample()` may fail if sample_count > 0, but min() prevents. Histograms may be empty. |
| File path encoding issues | File paths contain non-ASCII characters | Handle paths correctly | Uses Path objects, should handle Unicode paths. |
| OpenCV loading failures | cv2.imread fails for other reasons (e.g., permissions) | Skip and log or raise error | Returns None, skipped. No logging. |
| Invalid model_type in ClassifierService | A model_type other than 'random_forest' or 'svm' is passed | Raise a descriptive ValueError immediately | `__init__` raises `ValueError` with a message listing the supported options before any model is built. |
| Missing model file on load | `classifier.load()` is called but no saved model file exists | Raise a clear error indicating the file is missing | `joblib.load()` raises `FileNotFoundError`. No model is loaded and the error propagates to the caller. |
| Empty DataFrame passed to Preprocessor | `load_images()` is called with a DataFrame containing no rows | Return empty arrays without crashing | Loop does not execute, returning an empty numpy array and empty label array. |
| All images fail to load in Preprocessor | Every image path in the DataFrame is invalid or unreadable | Return empty arrays and continue | `cv2.imread()` returns None for each file, all are skipped, resulting in empty X and y arrays. |
| Missing model output directory | `MODEL_OUTPUT_DIR` does not exist when ClassifierService saves the model | Directory should be created automatically | `output_dir.mkdir(parents=True, exist_ok=True)` is called in `__init__`, so the directory is created before saving. |
| Class with no test samples in ModelEvaluator | A class present in training has no samples in the test split | Per-class accuracy should not raise a division error | `compute_per_class_accuracy()` checks `mask.sum() == 0` and assigns 0.0 for that class instead of dividing. |
| Single-class dataset | All images belong to one class | train_test_split with stratify should still work | `stratify=y` with one unique value will raise a `ValueError` from scikit-learn — not currently handled. |

## Testing Instructions

### Stage 1 — EDA
1. Test missing dataset folder: Remove or rename `data/raw/` and run DatasetIndexer.
2. Test invalid images: Place corrupted .jpg files in the dataset and run indexer.
3. Test missing output dir: Delete `outputs/eda/` and run EDAService methods.
4. Test invalid columns: Pass a DataFrame without "label" to EDAService.
5. Test unsupported formats: Add .txt files in dataset folders.

### Stage 2 — Classification
6. Test invalid model type: Call `ClassifierService(model_type="neural_net")` and confirm ValueError is raised.
7. Test missing model file: Call `classifier.load()` without first saving a model and confirm FileNotFoundError is raised.
8. Test empty DataFrame in Preprocessor: Pass an empty DataFrame to `load_images()` and confirm no exception is raised.
9. Test missing model output directory: Delete `outputs/models/` and call `classifier.save()` — confirm directory is recreated and file is saved.
10. Test per-class accuracy with missing class: Manually set `y_true` to exclude one class index and confirm `compute_per_class_accuracy()` returns 0.0 for that class without crashing.

Ensure the application does not crash and handles errors as described.
