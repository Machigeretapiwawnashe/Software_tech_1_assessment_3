"""Preprocessing service for preparing image data for classification."""

from pathlib import Path
import cv2
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from typing import Tuple, Union
from src.config import IMAGE_SIZE


class Preprocessor:
    """Load, resize, normalize, and encode image data for classification."""

    def __init__(self, image_size: Tuple[int, int] = IMAGE_SIZE) -> None:
        self.image_size = image_size
        self.label_encoder = LabelEncoder()

    def load_images(self, dataframe: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Load all images from DataFrame, resize, and return pixel arrays with labels."""
        pixel_arrays = []
        labels = []

        for _, row in dataframe.iterrows():
            image = cv2.imread(str(row["file_path"]))
            if image is None:
                continue
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            image = cv2.resize(image, self.image_size)

            pixel_arrays.append(image)
            labels.append(row["label"])

        X = np.array(pixel_arrays, dtype=np.float32) / 255.0
        y = self.label_encoder.fit_transform(labels)

        return X, y

    def load_image(self, image_path: Union[str, Path]) -> np.ndarray:
        """Load and preprocess a single image for prediction."""
        image = cv2.imread(str(image_path))
        if image is None:
            raise ValueError(f"Unable to load image: {image_path}")

        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image = cv2.resize(image, self.image_size)
        image = image.astype(np.float32) / 255.0
        return np.expand_dims(image, axis=0)

    def split(
        self,
        X: np.ndarray,
        y: np.ndarray,
        test_size: float = 0.2,
        random_state: int = 42,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Split data into training and test sets."""
        return train_test_split(
            X, y,
            test_size=test_size,
            random_state=random_state,
            stratify=y,
        )

    def get_class_names(self) -> list:
        """Return the original class names in label-encoded order."""
        return list(self.label_encoder.classes_)
