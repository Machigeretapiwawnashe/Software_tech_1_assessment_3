from stage3 import main_menu

if __name__ == "__main__":
    main_menu()
