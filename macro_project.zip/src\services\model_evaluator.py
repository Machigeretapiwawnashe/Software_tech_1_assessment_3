
"""Model evaluation service for generating and saving classification metrics and charts."""

from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
)
from typing import Dict, List
from src.config import MODEL_OUTPUT_DIR


class ModelEvaluator:
    """Generate classification metrics and evaluation charts."""

    def __init__(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        class_names: List[str],
        output_dir: Path = MODEL_OUTPUT_DIR,
    ) -> None:
        """Initialize with true labels, predictions, and class names."""
        self.y_true = y_true
        self.y_pred = y_pred
        self.class_names = class_names
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def build_report(self) -> Dict[str, object]:
        """Return a dictionary of per-class precision, recall, and F1-score."""
        # output_dict=True returns the report as a Python dict rather than a string
        return classification_report(
            self.y_true,
            self.y_pred,
            target_names=self.class_names,
            output_dict=True,
        )

    def save_confusion_matrix(self) -> None:
        """Save a confusion matrix heatmap."""
        cm = confusion_matrix(self.y_true, self.y_pred)

        plt.figure(figsize=(12, 10))
        sns.heatmap(
            cm,
            annot=True,
            fmt="d",
            cmap="Blues",
            xticklabels=self.class_names,
            yticklabels=self.class_names,
        )
        plt.title("Confusion Matrix — Macroinvertebrate Classifier")
        plt.xlabel("Predicted Label")
        plt.ylabel("True Label")
        plt.xticks(rotation=90)
        plt.yticks(rotation=0)
        plt.tight_layout()
        plt.savefig(self.output_dir / "confusion_matrix.png")
        plt.close()

    def save_accuracy_bar(self, per_class_accuracy: Dict[str, float]) -> None:
        """Save a bar chart showing per-class accuracy scores."""
        classes = list(per_class_accuracy.keys())
        scores = list(per_class_accuracy.values())

        plt.figure(figsize=(12, 6))
        colors = plt.cm.viridis(np.linspace(0, 1, len(classes)))
        plt.bar(classes, scores, color=colors)
        plt.xticks(rotation=90)
        plt.ylim(0, 1)
        plt.title("Per-Class Accuracy — Macroinvertebrate Classifier")
        plt.xlabel("Class")
        plt.ylabel("Accuracy")
        plt.tight_layout()
        plt.savefig(self.output_dir / "per_class_accuracy.png")
        plt.close()

    def compute_per_class_accuracy(self) -> Dict[str, float]:
        """Return accuracy computed separately for each class."""
        per_class = {}
        for idx, class_name in enumerate(self.class_names):
            mask = self.y_true == idx
            if mask.sum() == 0:
                per_class[class_name] = 0.0
                continue
            per_class[class_name] = float((self.y_pred[mask] == self.y_true[mask]).mean())
        return per_class
