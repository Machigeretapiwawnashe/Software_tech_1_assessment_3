"""Main entry point for the Macroinvertebrate Image Analysis System.

Run from the project root with:
    python main.py
"""

from src.config import EDA_OUTPUT_DIR, MODEL_OUTPUT_DIR, RAW_DATA_DIR
from src.services.dataset_indexer import DatasetIndexer
from src.services.eda_service import EDAService
from src.services.preprocessor import Preprocessor
from src.services.classifier_service import ClassifierService
from src.services.model_evaluator import ModelEvaluator


def run_stage_1(dataframe):
    """Run EDA and generate visualizations."""
    print("\n--- Stage 1: Exploratory Data Analysis ---")
    eda = EDAService(dataframe=dataframe, output_dir=EDA_OUTPUT_DIR)
    print("  Saving class distribution...")
    eda.save_class_distribution()
    print("  Saving image size distribution...")
    eda.save_image_size_distribution()
    print("  Saving sample image grid...")
    eda.save_sample_grid()
    print("  Saving class imbalance analysis...")
    eda.save_class_imbalance_analysis()
    print("  Saving pixel intensity analysis...")
    eda.save_pixel_intensity_analysis()
    print("  Writing Stage 2 commentary...")
    eda.build_stage2_commentary()
    summary = eda.build_summary()
    print(f"  Total images : {summary['total_images']}")
    print(f"  Total classes: {summary['total_classes']}")
    print(f"  Mean width   : {summary['mean_width']:.1f}px")
    print(f"  Mean height  : {summary['mean_height']:.1f}px")
    print(f"  EDA charts saved to: {EDA_OUTPUT_DIR}")


def run_stage_2(dataframe):
    """Preprocess images, train classifier, and save the model."""
    print("\n--- Stage 2: Classification ---")

    print("  Preprocessing images and splitting dataset...")
    preprocessor = Preprocessor()
    X, y = preprocessor.load_images(dataframe)
    X_train, X_test, y_train, y_test = preprocessor.split(X, y)
    class_names = preprocessor.get_class_names()
    print(f"  Training samples: {len(X_train)}, Test samples: {len(X_test)}")

    classifier = ClassifierService(model_type="random_forest", output_dir=MODEL_OUTPUT_DIR)
    print("  Training Random Forest classifier...")
    classifier.train(X_train, y_train)

    print("  Evaluating classifier...")
    accuracy = classifier.evaluate(X_test, y_test)
    print(f"  Test accuracy: {accuracy:.2%}")

    print("  Saving trained model...")
    save_path = classifier.save()
    print(f"  Model saved to: {save_path}")
    print("  Saving class name metadata...")
    class_names_path = classifier.save_class_names(class_names)
    print(f"  Class names saved to: {class_names_path}")

    print("  Generating evaluation charts...")
    y_pred = classifier.predict(X_test)
    evaluator = ModelEvaluator(
        y_true=y_test,
        y_pred=y_pred,
        class_names=class_names,
        output_dir=MODEL_OUTPUT_DIR,
    )
    evaluator.save_confusion_matrix()
    per_class = evaluator.compute_per_class_accuracy()
    evaluator.save_accuracy_bar(per_class)
    print(f"  Evaluation charts saved to: {MODEL_OUTPUT_DIR}")

    return classifier, preprocessor


def main():
    """Orchestrate all pipeline stages in sequence."""
    print("=== Macroinvertebrate Image Analysis System ===")

    # Index the raw dataset into a DataFrame
    print("\nIndexing dataset...")
    indexer = DatasetIndexer(data_dir=RAW_DATA_DIR)
    dataframe = indexer.build_dataframe()

    if dataframe.empty:
        print("  No images found. Please download the dataset to data/raw/")
        return

    run_stage_1(dataframe)
    run_stage_2(dataframe)

    print("\n=== Pipeline complete ===")


if __name__ == "__main__":
    main()
