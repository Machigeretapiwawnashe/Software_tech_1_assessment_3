from pathlib import Path
from main import main
from src.config import EDA_OUTPUT_DIR, MODEL_OUTPUT_DIR, RAW_DATA_DIR, SUPPORTED_EXTENSIONS
from src.services.classifier_service import ClassifierService
from src.services.preprocessor import Preprocessor
import numpy as np


def print_header() -> None:
    print("== Macroinvertebrate Image Analysis System — Stage 3 ==")
    print("1. Run full pipeline (Stage 1 + Stage 2)")
    print("2. Classify a new image using the saved model")
    print("3. Classify using selected classes")
    print("4. Show output directories")
    print("5. Exit")


def list_outputs() -> None:
    print(f"EDA output directory: {EDA_OUTPUT_DIR}")
    print(f"Model output directory: {MODEL_OUTPUT_DIR}")
    print()
    for directory in [EDA_OUTPUT_DIR, MODEL_OUTPUT_DIR]:
        print(f"Contents of {directory}:")
        if directory.exists():
            for path in sorted(directory.iterdir()):
                print(f"  - {path.name}")
        else:
            print("  (directory does not exist)")
        print()


def build_selected_classes(class_names: list[str]) -> list[str]:
    print("Available classes:")
    for index, name in enumerate(class_names, start=1):
        print(f"  {index}. {name}")

    selection = input(
        "Enter class numbers separated by commas (e.g. 1,3,4), or press Enter to cancel: "
    ).strip()
    if not selection:
        return []

    selected = []
    for token in selection.split(","):
        item = token.strip()
        if not item:
            continue
        if item.isdigit():
            idx = int(item)
            if 1 <= idx <= len(class_names):
                selected.append(class_names[idx - 1])
        elif item in class_names:
            selected.append(item)

    return list(dict.fromkeys(selected))


def choose_image_from_selected_classes(selected_classes: list[str]) -> Path | None:
    image_files = sorted(
        path
        for path in RAW_DATA_DIR.rglob("*")
        if path.suffix.lower() in SUPPORTED_EXTENSIONS
        and path.parent.name in selected_classes
    )

    if not image_files:
        print("No image was found for the selected classes.")
        return None

    print("Choose an image from the dataset:")
    for index, path in enumerate(image_files[:20], start=1):
        print(f"  {index}. {path.parent.name}/{path.name}")
    if len(image_files) > 20:
        print(f"  ...and {len(image_files) - 20} more images available")

    selection = input(
        "Enter image number, or full file path (press Enter to cancel): "
    ).strip()
    if not selection:
        return None

    if selection.isdigit():
        idx = int(selection)
        if 1 <= idx <= len(image_files):
            return image_files[idx - 1]
        print("Invalid image number.")
        return None

    image_file = Path(selection)
    if not image_file.exists() or not image_file.is_file():
        print(f"Image not found: {image_file}")
        return None

    return image_file


def choose_classification_scope() -> str | None:
    print("Choose classification scope:")
    print("  1. One image from selected classes")
    print("  2. All images in selected classes")
    choice = input("Enter 1 or 2 (press Enter to cancel): ").strip()
    if choice in {"1", "2"}:
        return choice
    print("Cancelled or invalid choice.")
    return None


def load_images_for_paths(image_files: list[Path]) -> np.ndarray:
    preprocessor = Preprocessor()
    images = []
    for image_file in image_files:
        try:
            loaded = preprocessor.load_image(image_file)
            images.append(loaded[0])
        except Exception:
            continue

    if not images:
        raise ValueError("No valid images could be loaded.")

    return np.stack(images, axis=0)


def classify_image(selected_classes: list[str] | None = None, X: np.ndarray | None = None, class_names: list[str] | None = None, classifier: ClassifierService | None = None) -> None:
    if X is None or class_names is None or classifier is None:
        model_path = MODEL_OUTPUT_DIR / "classifier.joblib"
        class_names_path = MODEL_OUTPUT_DIR / "class_names.txt"

        if not model_path.exists() or not class_names_path.exists():
            print("A trained model and class metadata are required.")
            print("Please run option 1 first to build and save the model.")
            return

        image_path = input("Enter the path to an image file: ").strip()
        if not image_path:
            print("No image path entered.")
            return

        image_file = Path(image_path)
        if not image_file.exists() or not image_file.is_file():
            print(f"Image not found: {image_file}")
            return

        try:
            preprocessor = Preprocessor()
            X = preprocessor.load_image(image_file)
        except Exception as exc:
            print(f"Error loading image: {exc}")
            return

        classifier = ClassifierService(output_dir=MODEL_OUTPUT_DIR)
        classifier.load()
        class_names = classifier.load_class_names()

    prediction = classifier.predict(X)
    predicted_class = class_names[prediction[0]]

    if selected_classes:
        selected_set = set(selected_classes)
        valid_selected = [name for name in selected_classes if name in class_names]
        if not valid_selected:
            print("None of the selected classes are available in the saved model.")
            return

        if hasattr(classifier.model, "predict_proba"):
            probabilities = classifier.model.predict_proba(classifier._flatten(X))[0]
            selected_probabilities = [
                (name, probabilities[class_names.index(name)])
                for name in valid_selected
            ]
            selected_probabilities.sort(key=lambda item: item[1], reverse=True)
            selected_prediction = selected_probabilities[0][0]

            print(f"Predicted class among selected classes: {selected_prediction}")
            if predicted_class not in selected_set:
                print(f"Note: the overall model top prediction was {predicted_class},")
                print("      but the best choice within the selected subset is shown above.")

            print("Top probabilities within selected classes:")
            for name, prob in selected_probabilities[:3]:
                print(f"  {name}: {prob:.2%}")
        else:
            print(f"Predicted class: {predicted_class}")
            if predicted_class not in selected_set:
                print("The predicted class is not within the selected classes.")
    else:
        print(f"Predicted class: {predicted_class}")
        if hasattr(classifier.model, "predict_proba"):
            probabilities = classifier.model.predict_proba(classifier._flatten(X))[0]
            ranked = sorted(
                zip(class_names, probabilities),
                key=lambda item: item[1],
                reverse=True,
            )
            print("Top probabilities:")
            for name, prob in ranked[:3]:
                print(f"  {name}: {prob:.2%}")


def main_menu() -> None:
    while True:
        print_header()
        choice = input("Choose an option (1-5): ").strip()
        print()

        if choice == "1":
            main()
        elif choice == "2":
            classify_image()
        elif choice == "3":
            model_path = MODEL_OUTPUT_DIR / "classifier.joblib"
            class_names_path = MODEL_OUTPUT_DIR / "class_names.txt"
            if not model_path.exists() or not class_names_path.exists():
                print("A trained model and class metadata are required.")
                print("Please run option 1 first to build and save the model.")
            else:
                classifier = ClassifierService(output_dir=MODEL_OUTPUT_DIR)
                classifier.load()
                class_names = classifier.load_class_names()
                selected_classes = build_selected_classes(class_names)
                if selected_classes:
                    print(f"Selected classes: {', '.join(selected_classes)}")
                    scope = choose_classification_scope()
                    if not scope:
                        continue

                    if scope == "1":
                        image_file = choose_image_from_selected_classes(selected_classes)
                        if not image_file:
                            continue

                        try:
                            preprocessor = Preprocessor()
                            X = preprocessor.load_image(image_file)
                        except Exception as exc:
                            print(f"Error loading image: {exc}")
                            continue

                        classify_image(selected_classes=selected_classes, X=X, class_names=class_names, classifier=classifier)
                    else:
                        image_files = sorted(
                            path
                            for path in RAW_DATA_DIR.rglob("*")
                            if path.suffix.lower() in SUPPORTED_EXTENSIONS
                            and path.parent.name in selected_classes
                        )
                        if not image_files:
                            print("No images found for the selected classes.")
                            continue

                        try:
                            X_batch = load_images_for_paths(image_files)
                        except ValueError as exc:
                            print(f"Error loading images: {exc}")
                            continue

                        predictions = classifier.predict(X_batch)
                        predicted_names = [class_names[idx] for idx in predictions]
                        print("Predictions for selected class images:")
                        from collections import Counter

                        counts = Counter(predicted_names)
                        for name, count in counts.most_common():
                            print(f"  {name}: {count}")

                        print("\nSample predictions:")
                        for path, pred in zip(image_files[:10], predicted_names[:10]):
                            print(f"  {path.parent.name}/{path.name} -> {pred}")
        elif choice == "4":
            list_outputs()
        elif choice == "5":
            print("Exiting Stage 3 deployment.")
            break
        else:
            print("Invalid option. Please choose 1, 2, 3, 4, or 5.")

        print()


if __name__ == "__main__":
    main_menu()
